package com.company.java008_ex;

import java.util.Scanner;

public class MethodEx006 {
	//public static 리턴값  메서드명(피라미터){해야할일}
	public static int process_total(int attack, int defense, int speed) {return attack+defense+speed;}
	public static float process_avg(float total) {return total / 3.0f;}
	public static String process_grade(float avg) {return avg>=90?"s등급": avg>=80?  "A등급": avg>=70? "B등급" : "C등급";}
	public static String process_star(float avg) { String result = ""; for (int i = 0; i < (int)(avg / 10); i++) {result += "★";} return result;}
	public static String process_quest(float avg) {return avg>=90? "전설의 용처치" : avg>=80? "전설의 호랑이처치" : avg>=70? "전설의 토끼처치" : "넌 퀘스트 받을 자격없다 더 강해져라!!!";}
	public static String process_type(int attack, int defense, int speed) {return attack >= defense && attack >= speed ? "전사형" :
		defense >= attack && defense >= speed ? "탱커형" : "도적형";}
	
	
	public static void main(String[] args) {
		//변수
		String name = "";
		int attack, defense, speed = 0;
		int total =0;
		float avg =0.0f;
		String grade, star, quest, type="";
		Scanner scanner = new Scanner(System.in);
		//입력
		System.out.println("캐릭터 이름>");
		name = scanner.next();
		System.out.println("공격력(0~100)>");
		attack = scanner.nextInt();
		System.out.println("방어력(0~100)>");
		defense = scanner.nextInt();
		System.out.println("민첩성(0~100)>");
		speed = scanner.nextInt();
		//처리 
		total=process_total(attack, defense, speed);
		avg=process_avg(total);
		grade = process_grade(avg);
        star = process_star(avg);
        quest = process_quest(avg);
        type = process_type(attack, defense, speed);
	 
		
		//출력
        process_show(name, attack, defense, speed, total, avg, grade, star, quest, type);		
	}
	public static void process_show(String name, int attack, int defense, int speed, int total, float avg, String grade, String star, String quest, String type) {
		System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		System.out.println("\"캐릭터\t공격력\t방어력\t민첩성\t총합\t평균\t등급\t랭킹\t추천퀘스트\t\t캐릭터타입");
		System.out.println("-------------------------------------------------------------------------------------------------");
		System.out.printf("%s\t%d\t%d\t%d\t%d\t%.1f\t%s\t%s\t%s\t%s\n",
		        name, attack, defense, speed, total, avg, grade, star, quest, type);
		System.out.println("-------------------------------------------------------------------------------------------------");
	}

}



/*클래스명: MethodEx006
1. 당신은 게임 캐릭터의 능력치를 분석하는 프로그램을 만들려고 합니다.  
사용자로부터 캐릭터 이름과 공격력, 방어력, 민첩성을 입력받아 
총합, 평균, 등급, 별표 랭킹, 추천 퀘스트, 캐릭터 타입을 출력하는 프로그램을 작성하세요.


#### (1단계) 변수 선언  
아래와 같은 변수를 선언하세요:
- `String name` : 캐릭터 이름  
- `int attack, defense, speed` : 능력치  
- `int total` : 능력치 총합  
- `float avg` : 평균  
- `String grade, star, quest, type` : 등급, 별표, 퀘스트, 캐릭터 타입  
- `Scanner scanner` : 입력 도구

#### (2단계) 입력 처리  
사용자로부터 다음 정보를 입력받으세요:
- 캐릭터 이름
- 공격력 (0~100)
- 방어력 (0~100)
- 민첩성 (0~100)

#### (3단계) 메서드 작성 및 호출  
아래 기능을 각각 메서드로 작성하고, main 메서드에서 호출하세요:

| 기능 | 메서드명 | 설명 |
|------|----------|------|
| 총합 계산 | `process_total()` | 공격력 + 방어력 + 민첩성 |
| 평균 계산 | `process_avg()` | 총합 ÷ 3 |
| 등급 처리 | `process_grade()` | 평균에 따라 S~D 등급 |
| 별표 처리 | `process_star()` | 평균 점수대별 별 개수 |
| 퀘스트 추천 | `process_quest()` | 평균에 따라 추천 퀘스트 |
| 캐릭터 타입 | `process_type()` | 가장 높은 능력치 기준 |


#### (4단계) 출력 메서드 작성  
`process_show()` 메서드를 만들어 다음 정보를 출력하세요:

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
캐릭터   공격력   방어력   민첩성   총합   평균   등급   랭킹   추천퀘스트   캐릭터타입
-------------------------------------------------------------------------------------------------
피카츄   85   90   95   270   90.0   S등급   *********   전설의 용 퇴치   도적형
-------------------------------------------------------------------------------------------------
 
###   보너스 과제 (선택)
- 평균이 100점이면 “전설의 영웅” 칭호를 부여해보세요.
- 여러 캐릭터를 배열로 입력받아 비교하는 기능으로 확장해보세요.*/