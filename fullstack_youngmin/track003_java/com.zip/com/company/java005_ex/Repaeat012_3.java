package com.company.java005_ex;

import java.util.Scanner;

public class Repaeat012_3 {
	public static void main(String[] args) {
		
		System.out.println("\n\nq1");
		for (int i=1; i<=5; i++) System.out.print(i+"\t");
		
		System.out.println("\n\nq2");
		for (int i=5; i>=1; i--) System.out.print(i+"\t");
		
		
		System.out.println("\n\nq3 JAVA1 JAVA2 JAVA3");
		for (int i=1; i>=5; i++) System.out.print("JAVA"+i);
	}
}
