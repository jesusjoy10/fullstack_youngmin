package com.company.java005_ex;

import java.util.Scanner;

public class IfEx020 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("문자 하나 입력하시오");
		char ch = scanner.next().charAt(0);
		
		if(ch=='a') {System.out.println("apple");}
		else if(ch=='b') {System.out.println("banana");}
		else if(ch=='c') {System.out.println("coconut");}
		else {System.out.println("a,b,c가 아니다");
		
		}
	}
}
