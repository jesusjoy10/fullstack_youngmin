package com.company.java005_ex;

import java.util.Scanner;

public class ForEx007 {
	public static void main(String[] args) {
		//변수
		double avg;
		int total; int kor; int math; int eng; 
		String std; 
		String pass, level, jang;
		
		Scanner scanner = new Scanner(System.in);
				
		//입력
		System.out.print("학번입력>");
		std= scanner.next();
		
		for(;;) {
			System.out.println("국어점수 입력>");
			kor= scanner.nextInt();
			if(0<=kor && kor <=100)
				{break;}
		}
		
		for(;;) {
			System.out.println("수학점수 입력>");
			math= scanner.nextInt();
			if(0<=math && math <=100)
				{break;}
		}
		
		for(;;) {
			System.out.println("영어점수 입력>");
			eng= scanner.nextInt();
			if(0<=eng && eng <=100)
				{break;}
		}
		
		
		//처리
		total= kor + math + eng;
		avg= total/3.0;
		pass= avg <60? "불합격" : kor<40 || eng<40 || math<40? "불합격":"합격";
		jang= avg <95? "":"장학생";
		level= avg >=90? "수": avg>=80? "우": avg>=70? "미" : avg>=60? "양" : "가";
		
			
				
		//결과	
		System.out.println("===================================================================================");
        System.out.println("학번   국어   영어   수학   총점   평균   합격여부   레벨   장학생");
        System.out.println("===================================================================================");
        System.out.printf("%s %5d %5d %5d %5d %5.2f   %-5s   %-5s   %-5s\n",
                std, kor, eng, math, total, avg, pass, level, jang);
	
		
		
	}

}

	/* 출력내용 :  성적처리 프로그램입니다.

1. 총점 구하기
2. 평균 구하기
3. 평균이 60점이상이고  각과목이 40점 미만이면 아니라면 합격/ 아니면 불합격
4. 평균이 95점이상이면 장학생
5. 평균이  90점이상이면 수, 80점이상이면 우, 70점이상이면 미, 60점이상이면 양, 아니라면 가 

학번 입력 > std111
국어점수 입력 > 100    ※ 0~100사이만입력받기
수학점수 입력 > 100    ※ 0~100사이만입력받기
영어점수 입력 > 99      ※ 0~100사이만입력받기

============================================================== 
학번   국어   영어   수학   총점   평균   합격여부   레벨   장학생
============================================================== 
std111   100   100   99   299   99.67   합격   수   장학생*/