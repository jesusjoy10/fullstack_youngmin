package com.company.java005_ex;

import java.util.Scanner;

public class ForEx020 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int num1;
		
		for(;;) {
			System.out.println("숫자를 입력하시오(1이 종료되면 ok)");
			num1= scanner.nextInt();
			if(num1==1) {
				System.out.println("종료"); break;
			}
		}
		
	
	}

}
