package com.company.java005_ex;

import java.util.Scanner;

public class Bank_ver1 {
	public static void main(String[] args) {
		System.out.println("Welcome (주)뱅크런 없는 영민은행");
		// 변수
		int num = 1;
		String id = null, pass = null;
		double balance = 0;

		Scanner scanner = new Scanner(System.in);
		// 입력+처리+출력

		for (;;) {
			System.out.println("====== BANK ======\n*" + "1.추가\n* 2.조회\n* 3.입금\n* 4.출금\n* 5.삭제\n* 9.종료\n* 입력>>>");

			int a = scanner.nextInt();
			if (a == 9) {
				System.out.println("atm을 종료합니다.");
				break;
			}

			switch (a) {
			case 1:
				System.out.println("1을 입력하면 추가기능입니다.");

				System.out.println("아이디 입력>");
				id = scanner.next();
				// 아이디입력 > _입력받기
				System.out.println("비밀번호 입력>");
				pass = scanner.next();
				// 비밀번호입력 > _입력받기
				System.out.println("잔액 입력>");
				balance = scanner.nextDouble();
				// 잔액입력 > _입력받기
				break;

			case 2: {
				System.out.println("2를 입력하면 조회기능입니다.");
				// 변수
				String tempid, temppass;
				// 입력 2-1 사용자에게 임시아이디와 임시비밀번호 입력받기
				System.out.println("임시아이디 입력>");
				tempid = scanner.next();
				System.out.println("임시비밀번호 입력>");
				temppass = scanner.next();
				// 2-2 아이디와 임시아이디가 같아야하고 비번과 임시비밀번호가 같다면 사용자 정보출력
				if (tempid.equals(id) && temppass.equals(pass)) {
					System.out.println("❗ 사용자정보");
					System.out.println("❗ id > " + id);
					System.out.println("❗ pass > " + pass);
					System.out.println("❗ balance > " + balance);
				}
				// 2-3 다르면 정보를 확인해주세요
				else {
					System.out.println("정보를 확인해주세요");
				}
			}
				break;

			case 3:
				System.out.println("3을 입력하면 입금기능입니다.");
				// 변수
				String tempid, temppass;
				// 입력 사용자에게 임시아이디와 임시비밀번호 입력받기
				System.out.println("임시아이디 입력>");
				tempid = scanner.next();
				System.out.println("임시비밀번호 입력>");
				temppass = scanner.next();
				// 처리 if(아이디와 임시아이디가 같고 비번과 임시비밀번호가 같다면) {돈입력 받아서, 잔액의 추가}
				if (tempid.equals(id) && temppass.equals(pass)) {
					System.out.println("입급 금액을 입력하세요");
					double money = scanner.nextDouble();
					balance += money;
					System.out.println("입금된 금액은" + money + "=" + "현재 잔액" + (balance) + "입니다.");
				}
				// 출력 else (아니라면 정보를 확인해주세요)
				else {
					System.out.println("정보를 확인해주세요");
				}
				break;

			case 4:
				System.out.println("4를 입력하면 출금기능입니다.");
				// 변수

				// 입력 사용자에게 임시아이디와 임시비밀번호 입력받기
				System.out.println("임시아이디 입력>");
				tempid = scanner.next();
				System.out.println("임시비밀번호 입력>");
				temppass = scanner.next();
				// 처리 if(아이디와 임시아이디가 같고 비번과 임시비밀번호가 같다면) { 돈입력받아서, 잔액에서 빼기)
				if (tempid.equals(id) && temppass.equals(pass)) {
					System.out.println("출금 금액을 입력하세요");
					double money = scanner.nextDouble();
					balance -= money;
					System.out.println("출금된 금액은" + money + "=" + "현재 잔액" + (balance) + "입니다.");
					// 출력 else (아니라면 정보를 확인해주세요)
				}
				break;

			case 5:
				System.out.println("5을 입력하면 삭제기능입니다.");
				// 변수
				// 입력
				System.out.println("임시아이디 입력>");
				tempid = scanner.next();
				System.out.println("임시비밀번호 입력>");
				temppass = scanner.next();

				if (tempid.equals(id) && temppass.equals(pass)) {
					System.out.println("정말 삭제하시겠습니까? (y/n)");
					String confirm = scanner.next(); // y/n 입력 받기
					if (confirm.equals("y")) { // y일 때 삭제
						id = null;
						pass = null;
						balance = 0;
						System.out.println("계정이 삭제되었습니다.");
					} else {
						System.out.println("삭제가 취소되었습니다.");
					}
				} else {
					System.out.println("정보를 확인해주세요");
				}
				break;

			}

		} // end for

	} // end main
} // end class

/*
 * 하루에 하나씩 힌트
 * 
 * 
 * Step1. 무한반복으로 만드는 메뉴 만들기
 * 
 * for(;;){//1-1 무한반복} 1-2 빠져나올조건 9 1-3 입력받은 번호가 if or switch 1을 입력하면 추가기능입니다.
 * 출력구문까지만 2를 입력하면 조회기능입니다. 출력구문까지만 3을 입력하면 추가기능입니다. 출력구문까지만 4를 입력하면 조회기능입니다.
 * 출력구문까지만 5을 입력하면 추가기능입니다. 출력구문까지만 9를 입력하면 조회기능입니다. 출력구문까지만
 * 
 * Step2. 무한반복으로 만드는 메뉴 만들기 //아이디입력 > _입력받기 //비밀번호입력 > _입력받기 //잔액입력 > _입력받기 ///
 * Step2
 */
