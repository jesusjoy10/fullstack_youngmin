package com.company.java005_ex;

public class ForEx008 {
	public static void main(String[] args) {
		// 1. for , while , do while문을 이용해서 다음과 같이 출력하시오 : 1 2 3 4 5
		System.out.println("for");
		for (int i = 1; i <= 5; i++) {
			System.out.print(i + "\t");
		}

		System.out.println("\n" + "while");
		int i = 1;
		while (i <= 5) {
			System.out.print(i + "\t");
			i++;
		}

		System.out.println("\n" + "do");
		i = 1;
		do {
			System.out.print(i + "\t");
			i++;
		} while (i <= 5);

		// 2. for , while , do while문을 이용해서 다음과 같이 출력하시오 : 5 4 3 2 1
		System.out.println("\n" + "for");
		for (int a =5; a >= 1; a--) {
			System.out.print(a + "\t");
		}
		
		System.out.println("\n" + "while");
		int a= 5;
		while (a >= 1) {
			System.out.print(a+"\t");
			a--;
		}
		System.out.println("\n" + "do");
		a= 5;
		do {
			System.out.print(a+"\t");
			a--;
		} while (a >= 1);
		
		//  for , while , do 문을 이용해서 다음과 같이 출력하시오 :  JAVA1   JAVA2  JAVA3
		
		System.out.println("\n"+"for");
		for(int b = 1; b<=3; b++) {
			System.out.print("JAVA"+b + "\t");
		}
		
		
		
		System.out.println("\n" + "while");
		int b =1;
		while (b <= 3) {
			System.out.print("JAVA"+b+"\t");
			b++;
		}
		
		System.out.println("\n"+"do");
		b=1;
		do {
			System.out.print("JAVA"+b+"\t");
			b++;
		} while (b<=3);
		

			
			
		}
		

	}



/*
 * 클래스명 : ForEx008 1. for , while , do while문을 이용해서 다음과 같이 출력하시오 : 1 2 3 4 5 2.
 * for , while , do while문을 이용해서 다음과 같이 출력하시오 : 5 4 3 2 1 3. for , while , do
 * while문을 이용해서 다음과 같이 출력하시오 : JAVA1 JAVA2 JAVA3
 */