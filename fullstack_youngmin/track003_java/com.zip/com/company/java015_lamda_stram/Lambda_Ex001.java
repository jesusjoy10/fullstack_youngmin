package com.company.java015_lamda_stram;

public class Lambda_Ex001 {
	interface InterC2 { String hi(); }

	interface Ex2 { void print(String s); }

	public static void main(String[] args) {
        // 1-1) 익명 클래스
        InterC2 c2 = new InterC2() {
            @Override public String hi() { return "Good :Day"; }
        };
        System.out.println(c2.hi());
        
        InterC2 c3 = new InterC2() {
            @Override public String hi() { return "Good :Day"; }
        };
        System.out.println(c3.hi());

        // 1-2) 람다식
        InterC2 c4 = () -> {return "Good :Day";};
        System.out.println(c4.hi());

        // Ex2
        //EX2 ex4 = (s)-> { System.out.println(s);};
        Ex2 ex2 = System.out::println;
        ex2.print("lambda :)");
    }
 }

