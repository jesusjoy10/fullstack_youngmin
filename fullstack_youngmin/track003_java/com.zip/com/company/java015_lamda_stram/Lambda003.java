package com.company.java015_lamda_stram;

class Refclass{void method(String str) {System.out.println(str);} }
interface InterUsing{void inter (Refclass c, String str);}

public class Lambda003 {
	public static void main(String[] args) {
		//#1. 익명클래스
		InterUsing a1 = new InterUsing() {		 
			@Override
			public void inter(Refclass c, String str) { c.method(str);}};
		    a1.inter(new Refclass(), "Hello: )");
		
		//#2. 람다()->{}
		    InterUsing a2 = (c ,str) -> { c.method(str); }; //직접구현
		    a1.inter(new Refclass(), "Hello: )");  // RefClass클래스의 method 사용
		
		//#3. :: 표현식(참조)
		    InterUsing  a3 = Refclass::method; // 자동연결 1) RefClass 2) method
		    a3.inter(new Refclass(), "Hello: )");
		//#4. interface InterBasic{int method(int a , int b);}
		    InterBasic basic = (int a, int b)-> { return Math.max(a, b);};
		    System.out.println(basic.method(10,3));
		    
		    InterBasic basic2 = ( a,  b)-> Math.max(a, b);
		    System.out.println(basic2.method(100,3));
		    
		    InterBasic basic3 = Math::max;
		    System.out.println(basic3.method(1000,3));
		    
		    InterBasic basic4 = (a,b)->Math.min(a, b); //()-> return
		    System.out.println(basic4.method(10, 3));
		    
		    InterBasic basic5 = Math::min; //()-> return
		    System.out.println(basic4.method(10, 3));
		    
		  //#4. interface  //순서 2) 어떤클래스갖고선 어떤메서드 사용했다
		    InterString basic6 = (a,b)->a.compareTo(b); //int java.lang.String.compareTo
		    System.out.println(basic6.compare("apple", "banana")); //음수
		    // 문자열이 같으면 0, <0  (음수)a<b  a가 b보다 앞에 옴  , (양수) a>b a가 b보다 뒤에옴
		    
		    InterString basic7 = String::compareTo; //int java.lang.String.compareTo
		    System.out.println(basic6.compare("coconut", "banana")); //음수
		    // 문자열이 같으면 0, <0  (음수)a<b  a가 b보다 앞에 옴  , (양수) a>b a가 b보다 뒤에옴
		    
		    InterParse basic8 = (s)-> Integer.parseInt(s);
		    System.out.println(basic8.parse("10")+3); // 13  문자열 + 숫자 계산
		    
		    InterParse basic9 = Integer::parseInt;
		    System.out.println(basic9.parse("10")+3); // 13  문자열 + 숫자 계산
		    
		    //InterParse basic10 = (a)-> {return Math.abs(a);};
		    InterAbs basic10 = Math::abs;
		    System.out.println(basic10.apply(-10)); 
		    
		    //InterParse basic10 = (s)-> { System.out.println(s);};
		    //InterParse basic10 = s-> System.out.println(s);
		    InterPrint basic11 = System.out::println;
		    basic11.print("hello Lambda");
		    
		    //ex1) 람다식 구현해주세요
		    //힌트)  System.out.println(ex1.getLenght("hello")); //결과 5   //String 클래스의 length
		   // Ex1 ex1 = (s) -> s.length();
		    Ex1 ex1 = String::length;
		    System.out.println(ex1.getLenght("hello")); 
		        	    
		    //ex2) 람다식 구현해주세요
		    //ex2. getLength("lambda:)");              // 출력 lambda:
		   // Ex2 ex2 = (String s) -> {System.out.println(s);};
		    Ex2 ex2 = System.out::println;
		    ex2.print("lambda:)");
		    
	}
}



interface InterBasic{int method(int a , int b);}
interface InterString{int compare(String a , String b);}  // 순서1) (a,b)->return 
interface InterParse{int parse(String s);} // (s) -> return
interface InterAbs{int apply(int a);} //(a)-> return
interface InterPrint{ void print(String s); } // (s) ->x 

interface Ex1{int getLenght(String s);}  //(String s)-> return int 
interface Ex2{void print (String s);} //(String s)-> x

