package com.company.java010_ex;

/* 초기화 :            기본값     				명시적초기화     초기화블록         생성자 
 * studentCount        0         			  =0            x0              x
 * maxScore            0        			  =100         x100             x
 * s1{name,kor,eng}   {name=null, kir=0,eng} {name=홍, kor =90, eng=85}     x  {name=홍, kor =90, eng=85}
 * s2{name,kor,eng}   {name=null, kir=0,eng} {name=홍, kor =90, eng=85}     x  {name=홍, kor =90, eng=85}
 * */ 

class Student {
    String name = "홍길동";    // 인스턴스 변수 - heap area - new o - 생성자 o   
    int kor = 90;             // 인스턴스 변수 - heap area - new o - 생성자 o     
    int eng = 85;             // 인스턴스 변수 - heap area - new o - 생성자 o    
    static int studentCount = 0;    // 클래스변수 , method  , new x  - 생성자 x >

    static int total;   // 클래스변수 , method  , new x  - 생성자 x >

    static int maxScore = 100;     // 클래스변수 , method  , new x  - 생성자 x >

    public Student() { //  생성자 o
        studentCount++;    // static 사용가능         
    }

    public int getTotalScore() { // 인스턴스 변수 - heap area - new o - 생성자 o    
        return this.kor + this.eng;        
    }

    public static void showStudentCount() {  // 클래스메서드, method  , new x  - 생성자 x >

        System.out.println("전체 학생 수: " + studentCount);  
    }

   public void showName() {  // 인스턴스 메서드 - heap area - new o - 생성자 o

         System.out.println(name);  
   }

    public void showInfo() { // 인스턴스 메서드 - heap area - new o - 생성자 o
        System.out.println("이름: " + name);            
        System.out.println("총점: " + getTotalScore());    
    }
}

public class MemberVarEx002 {
    public static void main(String[] args) { //지역변수
        Student s1 = new Student();     
        Student s2 = new Student();     

        s1.showInfo();                  
        Student.showStudentCount();    
    }
}
/*/*
------------------------[ runtime data area]
[method: 정보, static, final : 공용정보]
> Student.class   / MemberVarEx002. class
> Static : Student.studentCount , Student.maxScore, Student.showStudentCount() ,Student.showName() 
------------------------------------
[heap: 동적]                | [stack : 잠깐빌리기]
                         
2번지{ name=null, kor=90, eng=85
getTotalScore(), showInfo() } <- s2[2번지] 

1번지{ name=null, kor=90, eng=85
getTotalScore(), showInfo() } <- s1[1번지] 
                           | main
------------------------------------
*/

/*-- class Student 작성해주세요

- 문제 1. 다음 코드에서 인스턴스변수, 클래스변수, 지역변수를 구분하시오.  ( 보관되는 영역도 추가 )
- 문제 2. 인스턴스메서드와 클래스메서드를 구분하시오.  
- 문제 3. 오류가 발생하는 이유를 설명하시오.
- 문제 4. runtime data area 위치영역 그림그리기
*/