package com.company.java006_ex;

public class Test009 {
    public static void main(String[] args) {
        char[] chars = new char[3];
        char data = 'a';

        for (int i = 0; i < chars.length; i++) {
            chars[i] = data++;
        }

        for (int i = 0; i < chars.length; i++) {
            System.out.println(chars[i]);
        }
    }
}

