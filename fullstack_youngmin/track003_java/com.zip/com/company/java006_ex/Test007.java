package com.company.java006_ex;

public class Test007 {
    public static void main(String[] args) {
        for (int i = 5; i >= 1; i--) {
            System.out.print(i+""); }
        
        System.out.println("");
        
        int i = 5;while( i >= 1) {
            System.out.print(i+"");i-- ;}
        
        System.out.println("");
        
        int a = 5; do { System.out.print(a+"");a-- ;}
        while( a >= 1);
        
        
    }
}

