package com.company.java006_ex;

public class ArrayEx004 {
	public static void main(String[] args) {
		// 변수
		int cnt = 0;
		// 입력
		// 처리
		char[] ch = { 'b', 'a', 'n', 'a', 'n', 'a' };
		for (int a = 0; a < ch.length; a++) {
			if (ch[a] == 'a') {
				cnt++;
			}

		}
		System.out.println("'a'의 개수: " + cnt);
	}
}

/*
 * 클래스명 : ArrayEx004 1. 배열명 : ch 2. 값 넣기 : 'B' , 'a' , 'n' , 'a', 'n' , 'a' 3.
 * ch 배열에서 a의 갯수 세기
 */
