package com.company.java007_ex;

public class Array2Ex001 {
	public static void main(String[] args) {
		int[][] arr = {  {100,200,300}, // 00 01 02
				         {400,500,600}  // 10 11 12
		}; 
		for(int kan=0; kan<=2; kan++) {System.out.print(arr[0][kan]+"\t");}
		System.out.println();
		for(int kan=0; kan<=2; kan++) {System.out.print(arr[1][kan]+"\t");}
	}
	

}


/*배열을 이용하여 다음의 프로그램을 작성하시오.   
  
   int[][] arr2={{100,200,300},{400,500,600}};

   이중for 이용해서 출력하기
*/