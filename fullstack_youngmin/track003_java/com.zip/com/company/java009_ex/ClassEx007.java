package com.company.java009_ex;

import java.util.Scanner;

class Calc {
	// 상태-멤버변수 :
	int num1, num2;
	char op;
	double result;

	// 행위-멤버함수 : void input() 입력받기
	// void opcalc() +더하기계산, -라면 -계산 , *라면 *계산 , /라면 /계산
	// void show() 연산출력
	void input() {
		Scanner scanner = new Scanner(System.in);
		System.out.println();
		System.out.println("숫자1>");
		this.num1 = scanner.nextInt();
		System.out.print("숫자2>");
		this.num2 = scanner.nextInt();
		System.out.print("연산자>");
		this.op = scanner.next().charAt(0);
	}

	void opcalc() {
		if (this.op == '+') {
			this.result = this.num1 + this.num2;
		} else if (this.op == '-') {
			this.result = this.num1 - this.num2;
		} else if (this.op == '*') {
			this.result = this.num1 * this.num2;
		} else if (this.op == '/') {
			this.result = this.num1 / this.num2;
		}
	}

	void show() {
		this.opcalc();
		if (this.op == '/') {
			System.out.printf("%d %c %d = %.2f", this.num1, this.op, this.num2, this.result);
		} else {
			System.out.printf("%d %c %d = %d", this.num1, this.op, this.num2, (int) this.result);
		}
	}

	public Calc() {
		super();
	}

	public Calc(int num1, int num2, char op) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.op = op;
	}

	@Override
	public String toString() {
		return "Calc [num1=" + num1 + ", num2=" + num2 + ", op=" + op + ", result=" + result + "]";
	}
}

public class ClassEx007 {
	public static void main(String[] args) {
		Calc c1 = new Calc(10, 3, '+');
		c1.show(); // 10+3=3

		Calc c2 = new Calc();
		c2.input();
		c2.show();

	}
}
	            

/*클래스명 :  ClassEx007
-- 생성자 작성하시오.
class Calc{
   //상태-멤버변수  :  int num1, num2;  char op;  double result;
   //행위-멤버함수  :  void input()   입력받기
   //               void opcalc() +더하기계산, -라면 -계산  , *라면 *계산 , /라면 /계산 
   //                      void show()    연산출력   
}
public class ClassEx007{
   public static void main(String[] args) {
   Calc  c1= new Calc(10,3,'+');  
   c1.show();
   
   Calc  c2= new Calc();  
   c2.input();   
   c2.show(); 
    
   }
}

출력내용)
10+3=3

숫자1> 10
숫자2> 3
연산자> /
10/3=3.33*/