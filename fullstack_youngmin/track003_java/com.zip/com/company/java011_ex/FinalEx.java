package com.company.java011_ex;

//1. 클래스는 부품객체
//2. 클래스는 상태(멤버변수)와 행위(멤버변수)
	class User002 {
		//멤버변수
		   final String nation = "Korea";   
		   final String jumin;   
		   String name;
		//멤버함수
		   public User002() { jumin="00000"; }
		   public User002(String jumin, String name) {
		      this.jumin = jumin;
		      this.name = name;
		      
		   }
		   @Override
		   public String toString() {
			return "User002 [nation=" + nation + ", jumin=" + jumin + ", name=" + name + "]";
		   }
		}
		 public class FinalEx {
		   public static void main(String[] args) {
		      User002 user1 = new User002("123456-1234567", "아이유");
		      System.out.println(user1);   
		      
		     // user1.nation = "USA";      
		     //user1.jumin  = "123123-1234321";  //final은 외부수정 변경불가 
		      user1.name = "IU"; 
		      System.out.println(user1);   
		   }
		}
/*다음코드에서 오류나는 부분을 찾아 주석달고 이유를 적으시오.
class User002 {
   final String nation = "Korea";   
   final String jumin;   
   String name;

   public User002() { jumin="00000"; }
   public User002(String jumin, String name) {
      this.jumin = jumin;
      this.name = name;
   }
}
 public class FinalEx {
   public static void main(String[] args) {
      User002 user1 = new User002("123456-1234567", "아이유");
      System.out.println(user1);   
      
      user1.nation = "USA";      
      user1.jumin  = "123123-1234321"; 
      user1.name = "IU"; 
      System.out.println(user1);   
   }
}


 

*/