package com.company.java004_ex;

import java.util.Scanner;

public class IfEx006 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("숫자를 입력 받아");
		int num = scanner.nextInt();
		
		if (num%2==1) 
		{System.out.println("남자");}
		else 
		{System.out.println("여자");}
		
		
	
		
		
	}

}
