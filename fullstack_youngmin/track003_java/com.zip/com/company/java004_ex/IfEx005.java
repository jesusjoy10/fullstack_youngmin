package com.company.java004_ex;

import java.util.Scanner;

public class IfEx005 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("문자 한개를 입력하시오");
		char ch = scanner.next().charAt(0);

		if (ch >= 'A' && ch <= 'Z') {
			ch = (char) (ch + 32);
			System.out.println("소문자로 변환: " + ch);
		} else if (ch >= 'a' && ch <= 'z') {
			ch = (char) (ch - 32);
			System.out.println("대문자로 변환: " + ch);

		}

	}

}
