package com.company.java004_ex;

import java.util.Scanner;

public class Repeat010 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("숫자를 입력하시오");
		int num = scanner.nextInt();

		if (num == 1) {
			System.out.print("one");
		}

		else if (num == 2) {
			System.out.print("two");
		} else if (num == 3) {
			System.out.print("three");
		} else {
			System.out.print("1,2,3 이 아니다");
		}

	}

}
