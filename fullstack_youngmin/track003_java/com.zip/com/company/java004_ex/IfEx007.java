package com.company.java004_ex;

import java.util.Scanner;

public class IfEx007 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		 System.out.print("1. 정수를 하나 입력해주세요 > ");
	        int num1 = scanner.nextInt();
	        System.out.print("2. 정수를 하나 입력해주세요 > ");
	        int num2 = scanner.nextInt();
	        System.out.print("3. 연산자를 입력해주세요>");
	        char ch = scanner.next().charAt(0);
	        
	        if(ch=='+') {System.out.println(num1+"+"+num2+"="+(num1+num2));}
	        else if(ch=='-') {System.out.println(num1+"-"+num2+"="+(num1-num2));}
	        else if(ch=='*') {System.out.println(num1+"*"+num2+"="+(num1*num2));}
	        else {System.out.println(num1+"/"+num2+"="+((double)num1/num2));}
	        
	        
	        
	    
	        
	        
	        
	        
	        
		
		
		
		
		
	

}
}