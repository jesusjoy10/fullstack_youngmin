package com.company.java004_ex;

import java.util.Scanner;

public class SwtichEx003 {
	public static void main(String[]args) {
		int num1; int num2; char ch; 
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("정수를 하나 입력해주세요>");
		num1 =scanner.nextInt();
		System.out.println("정수를 하나 입력해주세요>");
		num2 =scanner.nextInt();
		System.out.println("연산자를 입력해주세요 (+,-,*,/) >");
		ch =scanner.next().charAt(0);
		
		switch(ch) { 
		case '+': System.out.println(num1+ "+"+num2+ "="+(num1+num2)); break;
		case '-': System.out.println(num1+ "-"+num2+ "="+(num1-num2)); break;
		case '*': System.out.printf("%d %c %d = %d" , num1,ch,num2, num1*num2); break;
		case '/': System.out.println(num1+ "/"+num2+ "="+((double)num1/num2)); break;
		}
	}

}


/* 연습문제3)  3
패키지명 : com.company.java004_ex
클래스명 :  SwtichEx003
출력내용 :  계산기

1. 정수를 하나 입력해주세요 > 10
2. 정수를 하나 입력해주세요 > 3
3. 연산자를 입력해주세요(+,-,*,/) > +
10+3=13

1. 정수를 하나 입력해주세요 > 10
2. 정수를 하나 입력해주세요 > 3
3. 연산자를 입력해주세요(+,-,*,/) > -
10-3=7 
*/