package com.company.java016_Javaio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Network002_naver {

	public static void main(String[] args) {
		
		try {
			//#1. URL
			String apiurl="https://openapi.naver.com/v1/search/book.json?query="
					+URLEncoder.encode("어린왕자","UTF-8");
			URL url =new URL(apiurl);
		
		//#2. HttpURLConnection
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		//#3. 요청설정
			//> X-Naver-Client-Id: {애플리케이션 등록 시 발급받은 클라이언트 아이디 값}
			//> X-Naver-Client-Secret: {애플리케이션 등록 시 발급받은 클라이언트 시크릿 값}
			conn.setRequestMethod("GET");
			conn.setRequestProperty("X-Naver-Client-Id", "pIH8EzWmBWdShk7ZtSpK");
			conn.setRequestProperty("X-Naver-Client-Secret", "y1oer_txj8");
		//#4. 응답확인
			BufferedReader br;
			
			if(conn.getResponseCode()==200) {
				br= new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} else {
				br= new BufferedReader(new InputStreamReader(conn.getInputStream()));		
			}
		//#5. 응답데이터
			String line="";
			StringBuffer sb= new StringBuffer();
			while((line = br.readLine()) != null) {sb.append(line + "\n");}
			
			System.out.println(sb.toString());
			br.close(); conn.disconnect();
		} catch (MalformedURLException e) {			
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {e.printStackTrace();}
	}
}

/*
1. ID Secret
Client ID                pIH8EzWmBWdShk7ZtSpK
Client Secret	   y1oer_txj8

2. 요청 URL 
https://openapi.naver.com/v1/search/book.xml	XML
https://openapi.naver.com/v1/search/book.json	JSON

3. HTTP 메서드  : GET

4.파라미터 - 요청내용을 주소표시창 줄에 데이터 넣어서 줄게 - 파라미터를 쿼리 스트링 형식으로 전달합니다.
파라미터	타입	필수 여부	설명
query	String	Y	검색어. UTF-8로 인코딩되어야 합니다.


https://openapi.naver.com/v1/search/book.query = 사용자가 요청한 값 (쿼리 스트링 형식)
https://openapi.naver.com/v1/search/book.qurey = 사용자가 요청한 값

*/